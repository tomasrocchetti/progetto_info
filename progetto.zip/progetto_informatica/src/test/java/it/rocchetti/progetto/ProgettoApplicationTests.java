package it.rocchetti.progetto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoApplicationTests {

	@Test
	void contextLoads() {
	}

}
